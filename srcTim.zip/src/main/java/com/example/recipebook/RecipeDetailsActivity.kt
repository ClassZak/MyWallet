package com.example.recipebook

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.recipebook.databinding.ActivityRecipeDetailsBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class RecipeDetailsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRecipeDetailsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRecipeDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val recipe = intent.getParcelableExtra<Recipe>("recipe")
        recipe?.let {
            displayRecipeDetails(it)
        }

        binding.btnAddToFavorites.setOnClickListener {
            recipe?.let {
                toggleFavorite(it)
            }
        }

        binding.btnDeleteRecipe.setOnClickListener {
            recipe?.let {
                deleteRecipe(it)
            }
        }

        binding.btnEditRecipe.setOnClickListener {
            recipe?.let { editRecipe(it) }
        }
    }

    private fun displayRecipeDetails(recipe: Recipe) {
        binding.tvTitle.text = recipe.title
        binding.tvIngredients.text = recipe.ingredients
        binding.tvSteps.text = recipe.steps
        binding.btnAddToFavorites.text = if (recipe.isFavorite) "Удалить из избранного" else "Добавить в избранное"

        // Устанавливаем изображение, если оно есть
        if (!recipe.imageUri.isNullOrEmpty()) {
            val uri = Uri.parse(recipe.imageUri)
            binding.ivRecipeImage.setImageURI(uri)
        } else {
            binding.ivRecipeImage.setImageResource(R.drawable.placeholder_image) // Установите изображение-заглушку
        }
    }

    private fun toggleFavorite(recipe: Recipe) {
        CoroutineScope(Dispatchers.IO).launch {
            val updatedRecipe = recipe.copy(isFavorite = !recipe.isFavorite)
            RecipeDatabase.getInstance(this@RecipeDetailsActivity).recipeDao().updateRecipe(updatedRecipe)
            withContext(Dispatchers.Main) {
                val message = if (updatedRecipe.isFavorite) "Рецепт добавлен в избранное" else "Рецепт удалён из избранного"
                Toast.makeText(this@RecipeDetailsActivity, message, Toast.LENGTH_SHORT).show()
                displayRecipeDetails(updatedRecipe)

                setResult(RESULT_OK)
            }
        }
    }

    private fun deleteRecipe(recipe: Recipe) {
        CoroutineScope(Dispatchers.IO).launch {
            RecipeDatabase.getInstance(this@RecipeDetailsActivity).recipeDao().deleteRecipe(recipe)
            withContext(Dispatchers.Main) {
                Toast.makeText(this@RecipeDetailsActivity, "Рецепт успешно удалён", Toast.LENGTH_SHORT).show()

                setResult(RESULT_OK)
                finish()
            }
        }
    }

    private fun editRecipe(recipe: Recipe) {
        val intent = Intent(this, AddRecipeActivity::class.java)
        intent.putExtra("recipe", recipe)
        startActivityForResult(intent, REQUEST_CODE_EDIT_RECIPE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_EDIT_RECIPE && resultCode == RESULT_OK) {
            val updatedRecipe = data?.getParcelableExtra<Recipe>("updated_recipe")
            updatedRecipe?.let {
                displayRecipeDetails(it)
                setResult(RESULT_OK)
            }
        }
    }

    companion object {
        private const val REQUEST_CODE_EDIT_RECIPE = 2
    }
}
