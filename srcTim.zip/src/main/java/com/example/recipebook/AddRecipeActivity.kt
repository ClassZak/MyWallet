package com.example.recipebook

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.recipebook.databinding.ActivityAddRecipeBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AddRecipeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddRecipeBinding
    private var imageUri: Uri? = null // Хранение URI изображения

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddRecipeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Проверяем, есть ли рецепт для редактирования
        val recipeToEdit = intent.getParcelableExtra<Recipe>("recipe")
        recipeToEdit?.let { populateFields(it) }

        binding.btnChooseImage.setOnClickListener {
            chooseImage()
        }

        binding.btnSaveRecipe.setOnClickListener {
            if (recipeToEdit != null) {
                updateRecipe(recipeToEdit)
            } else {
                saveRecipe()
            }
        }
    }

    // Заполняем поля для редактирования рецепта
    private fun populateFields(recipe: Recipe) {
        binding.etTitle.setText(recipe.title)
        binding.etIngredients.setText(recipe.ingredients)
        binding.etSteps.setText(recipe.steps)

        // Устанавливаем изображение, если оно есть
        recipe.imageUri?.let {
            imageUri = Uri.parse(it)
            binding.ivRecipeImage.setImageURI(imageUri)
        }
    }

    // Выбор изображения из галереи
    private fun chooseImage() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, REQUEST_CODE_PICK_IMAGE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_PICK_IMAGE && resultCode == Activity.RESULT_OK) {
            imageUri = data?.data
            binding.ivRecipeImage.setImageURI(imageUri) // Устанавливаем выбранное изображение
        }
    }

    // Сохраняем новый рецепт
    private fun saveRecipe() {
        val title = binding.etTitle.text.toString()
        val ingredients = binding.etIngredients.text.toString()
        val steps = binding.etSteps.text.toString()

        if (title.isBlank() || ingredients.isBlank() || steps.isBlank()) {
            Toast.makeText(this, "Пожалуйста, заполните все поля", Toast.LENGTH_SHORT).show()
            return
        }

        val recipe = Recipe(
            title = title,
            ingredients = ingredients,
            steps = steps,
            imageUri = imageUri?.toString(), // Сохраняем URI изображения
            isFavorite = false
        )

        CoroutineScope(Dispatchers.IO).launch {
            RecipeDatabase.getInstance(this@AddRecipeActivity).recipeDao().insertRecipe(recipe)
            withContext(Dispatchers.Main) {
                Toast.makeText(this@AddRecipeActivity, "Рецепт успешно сохранён", Toast.LENGTH_SHORT).show()

                // Устанавливаем результат и завершаем активность
                setResult(RESULT_OK)
                finish()
            }
        }
    }

    // Обновляем существующий рецепт
    private fun updateRecipe(oldRecipe: Recipe) {
        val updatedRecipe = oldRecipe.copy(
            title = binding.etTitle.text.toString(),
            ingredients = binding.etIngredients.text.toString(),
            steps = binding.etSteps.text.toString(),
            imageUri = imageUri?.toString() // Обновляем URI изображения

        )


        CoroutineScope(Dispatchers.IO).launch {
            RecipeDatabase.getInstance(this@AddRecipeActivity).recipeDao().updateRecipe(updatedRecipe)
            withContext(Dispatchers.Main) {
                Toast.makeText(this@AddRecipeActivity, "Рецепт успешно обновлён", Toast.LENGTH_SHORT).show()

                // Устанавливаем результат и завершаем активность
                setResult(RESULT_OK)
                finish()
            }
        }
    }

    companion object {
        private const val REQUEST_CODE_PICK_IMAGE = 1
    }
}
